package com.siyal.frameanimation;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private AnimationDrawable batAnimation;
    private ImageView batImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        batImage = (ImageView) findViewById(R.id.imgBat);

        batImage.setBackgroundResource(R.drawable.bat_anim);
        batAnimation = (AnimationDrawable) batImage.getBackground();


    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        batAnimation.start();     //Animation will start

        //To stop application
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //stop here
                batAnimation.stop();
            }
        }, 5000);     //5000 means 5 seconds or 5 second ke bad run method ka code chlega
        return super.onTouchEvent(event);
    }
}
