package codeWithWaqar.textviewandbutton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;    //To use Button
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.button);     //To get reference of the button
        textView = (TextView) findViewById(R.id.textView);

        button.setText(R.string.button_name);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                textView.setVisibility(View.VISIBLE);
                textView.setText(R.string.show_text);
            }
        });
    }

    /* One way of doing is select button and onClick set the method showMe
    public void showMe(View view){
        textView.setVisibility(View.VISIBLE);
        textView.setText(R.string.show_text);
    }*/
}
