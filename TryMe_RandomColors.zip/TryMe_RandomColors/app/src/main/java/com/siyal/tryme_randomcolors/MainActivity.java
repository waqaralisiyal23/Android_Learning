package com.siyal.tryme_randomcolors;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private View windowView;
    private Button tryMe;
    private int []colors;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        windowView = findViewById(R.id.background);
        tryMe = (Button) findViewById(R.id.button);

        colors = new int[]{Color.CYAN,Color.GREEN,Color.RED,Color.BLACK,Color.BLUE,Color.DKGRAY,Color.LTGRAY,Color.MAGENTA,Color.YELLOW};

        windowView.setBackgroundColor(colors[2]);

        tryMe.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Random random = new Random();
                int randomNumber = random.nextInt(colors.length);     //range from 0 to length-1 of array
                windowView.setBackgroundColor(colors[randomNumber]);
            }
        });
    }
}
