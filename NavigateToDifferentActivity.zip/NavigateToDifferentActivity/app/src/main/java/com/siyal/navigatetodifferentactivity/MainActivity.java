package com.siyal.navigatetodifferentactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button gotoSecondActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gotoSecondActivity = (Button) findViewById(R.id.showNextActivity);
        gotoSecondActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //An intent in android is an action. The action we need is to go from first activity to the next
                //In intent object constructor we pass thow things current activity and the activity in which we switch

                /*First Way:
                Intent intent = new Intent(MainActivity.this,SecondActivity.class);
                startActivity(intent);
                 */

                //Second way
                startActivity(new Intent(MainActivity.this,SecondActivity.class));
            }
        });
    }
}
