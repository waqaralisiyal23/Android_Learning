package com.siyal.countdowntimer_runnable_handler;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView txtCountDownTimer;

    private Handler handler;
    private Runnable runnable;

    private int number=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtCountDownTimer = (TextView) findViewById(R.id.txtCountDownTimer);

        //Task Scheduler using Runnable and Handler  : is mn chlta he jyega cde rukgea ni
//        handler = new Handler();
//        runnable = new Runnable() {
//            @Override
//            public void run() {
//                //code to execute
//                number++;
//                Toast.makeText(MainActivity.this,"This is toast "+number,Toast.LENGTH_LONG).show();
//                handler.postDelayed(this,1000);
//            }
//        };
//        handler.post(runnable);


        new CountDownTimer(10000,1000){
            @Override
            public void onTick(long millisUntilFinished) {
                number++;
                txtCountDownTimer.setText("Count Down Timer: "+number);
            }

            @Override
            public void onFinish() {
                txtCountDownTimer.setText("onFinish");
            }
        }.start();


    }
}
