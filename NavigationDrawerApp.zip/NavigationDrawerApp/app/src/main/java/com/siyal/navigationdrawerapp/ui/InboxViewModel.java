package com.siyal.navigationdrawerapp.ui;

import androidx.lifecycle.ViewModel;

public class InboxViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
