package com.siyal.seekbar;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private SeekBar seekBar;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seekBar = (SeekBar) findViewById(R.id.seekBar);
        result = (TextView) findViewById(R.id.txtResult);

        result.setText("Pain Level: "+ seekBar.getProgress() + "/" + seekBar.getMax());   //start mn 0/10 huga

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                //Log.d("SB","OnProgress!");
                result.setText("Pain Level: "+ seekBar.getProgress() + "/" + seekBar.getMax());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //Log.d("SB","OnStartTrackingTouch!");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //Log.d("SB","OnStop!");
                if(seekBar.getProgress()>=7)
                    result.setTextColor(Color.RED);
                else
                    result.setTextColor(Color.DKGRAY);
            }
            /*jab usko agy brhane ke liye click krengy tou onStartTrackingTouch pe huga jab brha rhe hain hungy onProgressChanged huga or
            jab chor dengy tou onStopTrackingTouch pe */
        });
    }
}
