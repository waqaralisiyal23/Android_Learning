package com.siyal.stopwatch;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btnStart;
    private Button btnStop;
    private Button btnReset;
    private TextView timeView;

    private int seconds;
    private boolean running;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //setting the value when the device is rotated
        if(savedInstanceState!=null){
            seconds = savedInstanceState.getInt("seconds");
            running = savedInstanceState.getBoolean("running");
        }

        btnStart = (Button) findViewById(R.id.btnStart);
        btnStop = (Button) findViewById(R.id.btnStop);
        btnReset = (Button) findViewById(R.id.btnReset);
        timeView = (TextView) findViewById(R.id.txtTime);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                running = true;
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                running = false;
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seconds = 0;
                running = false;
            }
        });

        runTimer();
    }

    private void runTimer(){

        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                int hours = seconds/3600;
                int minutes = (seconds%3600)/60;
                int secs = seconds%60;

                String time = String.format("%02d:%02d:%02d",hours,minutes,secs);   ////%02d is for 2 decimal places
                timeView.setText(time);

                if(running)
                    ++seconds;

                handler.postDelayed(this,1000);   //delay of 1 second becuase time changes after each second
            }
        });

    }

    //When device is rotated the time starts from 0 so to fix this problem
    public void onSaveInstanceState(Bundle saveInstanceState) {
        saveInstanceState.putInt("seconds",seconds);
        saveInstanceState.putBoolean("running",running);
        super.onSaveInstanceState(saveInstanceState);
    }
}
