package com.siyal.tictactoe;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private int fillBoxes=0;
    //0 - X
    //1 - O

    private int activePlayer=0;   //activePlayer=0 means X active hai
    private int []gameState={2,2,2,2,2,2,2,2,2};

    /*
    state meanings
    0 - X
    1 - O
    2 - Null
     */

    private String winner=null;


    //There are 8 winning positions - 3 horizontal and 3 vertical and 2 in cross
    private int [][]winningPositions={{0,1,2},{3,4,5},{6,7,8},
                              {0,3,6},{1,4,7},{2,5,8},
                              {0,4,8},{2,4,6}};



    public void playerTap(View view){
        ImageView img = (ImageView) view;
        int tappedImage = Integer.parseInt(view.getTag().toString());   //humn tag milega 0-8 ke kahan tap hua hai

        if(gameState[tappedImage]==2){   //2 means null agr jahan tap kiya hai wahan null hai tou he image add hugi X ya O
            gameState[tappedImage] = activePlayer;    //mtlb ab us jaga 0 ya 1 chla jyega means wo next time null ni hugi
            img.setTranslationY(-1000f);   //image ko upr se neeche lane ka animation dene ke liye abhi isko agy wapis set krngy or X dengy tou horizontally
                                            //image ayegi left se

            //To change the turn
            if(activePlayer==0){
                img.setImageResource(R.drawable.x);    //Agr 0 huga tou X ki turn hai
                activePlayer=1;
                status.setText("O's turn - Tap to play");

            }
            else{
                img.setImageResource(R.drawable.o);    //or 1 huga tou O ki turn hai
                activePlayer=0;
                status.setText("X's turn - Tap to play");
            }

            img.animate().translationYBy(1000f).setDuration(300);
            fillBoxes++;
        }
        else if(gameState[tappedImage]==0 || gameState[tappedImage]==1){
            Toast.makeText(MainActivity.this,"Box already filled. Try another!",Toast.LENGTH_SHORT).show();
        }

        //Check Winning Condition
        for(int []winPosition: winningPositions){
            if(gameState[winPosition[0]]==gameState[winPosition[1]] && gameState[winPosition[1]]==gameState[winPosition[2]] && gameState[winPosition[0]]!=2){
                //Somebody has won - Find who
                //String winner;
                if(gameState[winPosition[0]] == 0){
                    winner = "X has Won!";

                }
                else {
                    winner = "O has won!";
                }
                status.setText(winner);
                Toast.makeText(MainActivity.this,winner,Toast.LENGTH_LONG).show();
                showDialog();

            }
            else if(fillBoxes==9){
                status.setText("Match Drawn!");
                Toast.makeText(MainActivity.this,"Match Drawn!",Toast.LENGTH_LONG).show();
                showDialog();
                fillBoxes=0;
            }
        }
    }

    public void gameReset(){
        activePlayer=0;
        for(int i=0;i<gameState.length;i++){
            gameState[i]=2;
        }
        view1.setImageResource(0);
        view2.setImageResource(0);
        view3.setImageResource(0);
        view4.setImageResource(0);
        view5.setImageResource(0);
        view6.setImageResource(0);
        view7.setImageResource(0);
        view8.setImageResource(0);
        view9.setImageResource(0);

        status.setText("X's turn - Tap to play");
        fillBoxes=0;

    }

    private ImageView view1;
    private ImageView view2;
    private ImageView view3;
    private ImageView view4;
    private ImageView view5;
    private ImageView view6;
    private ImageView view7;
    private ImageView view8;
    private ImageView view9;
    private TextView status;

    private AlertDialog.Builder alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        view1 = (ImageView) findViewById(R.id.one);
        view2 = (ImageView) findViewById(R.id.two);
        view3 = (ImageView) findViewById(R.id.three);

        view4 = (ImageView) findViewById(R.id.four);
        view5 = (ImageView) findViewById(R.id.five);
        view6 = (ImageView) findViewById(R.id.six);

        view7 = (ImageView) findViewById(R.id.seven);
        view8 = (ImageView) findViewById(R.id.eight);
        view9 = (ImageView) findViewById(R.id.nine);

        status = (TextView) findViewById(R.id.status);

        view1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playerTap(v);
            }
        });

        view2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playerTap(v);
            }
        });

        view3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playerTap(v);
            }
        });

        view4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playerTap(v);
            }
        });

        view5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playerTap(v);
            }
        });

        view6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playerTap(v);
            }
        });

        view7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playerTap(v);
            }
        });

        view8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playerTap(v);
            }
        });

        view9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playerTap(v);
            }
        });

    }

    private void showDialog(){
        alertDialog = new AlertDialog.Builder(MainActivity.this);  //alertDialog belongs to the MainActivity
        //setting things up-set title
        //alertDialog.setTitle(R.string.title);   //There is another way to use string like this
        alertDialog.setTitle(getResources().getString(R.string.app_name));
        //sets the icon
        alertDialog.setIcon(android.R.drawable.btn_star_big_on);
        //set message
        alertDialog.setMessage(winner+"\n"+getResources().getString(R.string.message));
        //set cancelable
        alertDialog.setCancelable(false);   //means user yes ya no select krega cancel ni kr skta dialog ko
        //set positive button
        alertDialog.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                gameReset();
            }
        });
        //set negative button
        alertDialog.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                MainActivity.this.finish();    //Application exit hujyegi
            }
        });

        //creating the actual dialog
        AlertDialog dialog = alertDialog.create();
        dialog.show();

    }

}
