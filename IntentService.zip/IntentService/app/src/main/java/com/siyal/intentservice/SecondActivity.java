package com.siyal.intentservice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    private TextView txtReceivedMessage;
    Bundle extras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        txtReceivedMessage = (TextView) findViewById(R.id.txtReceivedMessage);

        extras = getIntent().getExtras();

        if(extras!=null){
            txtReceivedMessage.setText(extras.getString("text"));
        }
    }
}
