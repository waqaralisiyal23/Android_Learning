package com.siyal.intentservice;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;

public class MyService extends Service {
    public MyService() {
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(this,"Method 2: onStartCommand Called",Toast.LENGTH_LONG).show();

        Runnable r = new Runnable() {
            @Override
            public void run() {
                for(int i=0;i<5;i++){
                    long futureTime = System.currentTimeMillis() + 5000; //50000 ms means 5 sec
                    while(System.currentTimeMillis()<futureTime){
                        synchronized (this){
                            try{
                                wait(futureTime-System.currentTimeMillis());
                                Toast.makeText(MyService.this,"Service is Running",Toast.LENGTH_LONG).show();
                            }
                            catch (Exception e){

                            }
                        }
                    }
                }
            }
        };

        Thread thread = new Thread(r);
        thread.start();
        return Service.START_STICKY;   //It will restart the service if the service is crashes

    }

    @Override
    public void onDestroy() {
        Toast.makeText(this,"The service has destroyed",Toast.LENGTH_LONG).show();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
