package com.siyal.workoutadvisorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Spinner workoutType;
    private Button btnFindWorkout;
    private TextView txtShowWorkout;

    private List<String> workout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        workoutType = (Spinner) findViewById(R.id.workoutType);
        btnFindWorkout = (Button) findViewById(R.id.btnFindWorkout);
        txtShowWorkout = (TextView) findViewById(R.id.txtShowWorkout);

        btnFindWorkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String workout = workoutType.getSelectedItem().toString();
                //txtShowWorkout.setText(workout);
                List<String> workoutList = getWorkouts(workout);
                StringBuilder workouts = new StringBuilder("");

                for(int i=0;i<workoutList.size();i++){
                    workouts.append(workoutList.get(i)+"\n");
                }

                txtShowWorkout.setText(workouts);
            }
        });
    }

    public List<String> getWorkouts(String workoutType){
        workout = new ArrayList<>();
        if(workoutType.equals("Chest")){
            workout.add("Bench Press");
            workout.add("Cable Flys");
        }
        else if (workoutType.equals("Biceps")){
            workout.add("Bicep Curls");
        }
        else if (workoutType.equals("Triceps")){
            workout.add("Tricep Ext");
            workout.add("Tricep PushDowns");
        }
        else if (workoutType.equals("Shoulders")){
            workout.add("Shoulder Press");
        }
        return workout;
    }
}
