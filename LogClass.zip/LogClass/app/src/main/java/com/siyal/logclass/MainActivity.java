package com.siyal.logclass;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    /*Log class allow us to produce output in console. We have different levels but all have almost same purpose. It resides in
    android.util package and make sure you can remove all Log from your application. They are generally used for debugging
    and we can also use to check something etc..
     */
    private static final String TAG="MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG,"Hello from MainActivity");
        Log.v(TAG,"Hello from MainActivity");
    }
}
