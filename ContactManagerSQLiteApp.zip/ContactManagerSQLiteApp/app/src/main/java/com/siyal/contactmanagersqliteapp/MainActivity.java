package com.siyal.contactmanagersqliteapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.util.List;

import data.DatabaseHandler;
import model.Contact;

public class MainActivity extends AppCompatActivity {

    DatabaseHandler myDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDB = new DatabaseHandler(getApplicationContext());

        //insert contacts
        Log.d("Insert: ","Inserting.....");
//        myDB.addContact(new Contact(1,"Ghulam Nabi Siyal","0302-2810207"));
//        myDB.addContact(new Contact(2,"Ahmed Ali Siyal","0303-54254"));
//        myDB.addContact(new Contact(3,"Waqar Ali Siyal","0341-8777978"));
//        myDB.addContact(new Contact(4,"fegwe","898787"));


        //Read them back
        Log.d("Read: ","Reading all contacts......");
        List<Contact> contactList = myDB.getAllContacts();
        for(Contact c : contactList){
            String log = "Id: "+c.getId()+", Name: "+c.getName()+", Phone Number: "+c.getPhoneNumber();
            Log.d("Record: ",log);
        }

        //Get one contact
        Contact oneContact = myDB.getContact(1);
        String log2 = "Id: "+oneContact.getId()+", Name: "+oneContact.getName()+", Phone Number: "+oneContact.getPhoneNumber();
        Log.d("One Contact",log2);

        //update contact
//        boolean isUpdated = myDB.updateContact(new Contact(4,"Imtiaz Aandal","0300-4576894"));
//        if(isUpdated)
//            Log.d("Update: ","Updated Successfully....");

        //delete contact
//        boolean isDeleted = myDB.deleteContact(4);
//        if(isDeleted)
//            Log.d("Delete: ","Deleted Successfully......");

        //count contacts
        int count = myDB.getContactsCount();
        Log.d("Contacts count: ",String.valueOf(count));
    }
}
