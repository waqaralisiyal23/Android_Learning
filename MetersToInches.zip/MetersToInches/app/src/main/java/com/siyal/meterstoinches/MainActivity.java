package com.siyal.meterstoinches;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    /*
        1m = 39.3701in
     */
    private EditText meters;
    private Button btnConvert;
    private TextView showResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        meters = (EditText) findViewById(R.id.txtMeters);
        btnConvert = (Button) findViewById(R.id.btnConvert);
        showResult = (TextView) findViewById(R.id.txtResult);

        btnConvert.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                double result = 0.0;
                if( !(meters.getText().toString().isEmpty()) ) {
                    result = Double.parseDouble(meters.getText().toString()) * 39.3701;

                    //showResult.setText(Double.toString(result)+" inches");
                    //To show upto two decimal points
                    showResult.setText(String.format("%.2f", result) + " inches");
                    showResult.setTextColor(Color.DKGRAY);
                }
                else {
                    showResult.setText(R.string.error_message);
                    showResult.setTextColor(Color.RED);
                }
            }
        });


    }
}
