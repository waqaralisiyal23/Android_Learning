package com.siyal.notification;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button myButton;

    NotificationCompat.Builder notification;
    private static final int uniqueID=40111;     //to assign unique id to the notification

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myButton = (Button) findViewById(R.id.myButton);

        notification = new NotificationCompat.Builder(MainActivity.this);
        notification.setAutoCancel(true);

        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //first we will set the notification icon
                notification.setSmallIcon(R.drawable.ic_launcher_background);
                //now we will set the ticker
                notification.setTicker("This is a ticker");
                //set the time
                notification.setWhen(System.currentTimeMillis());
                //set the content titie
                notification.setContentTitle("This is a title");
                //set the content
                notification.setContentText("Here is the text");

                //When the user tap the notification we have to take the user back to the application
                Intent intent = new Intent(MainActivity.this,MainActivity.class);

                PendingIntent pendingIntent = PendingIntent.getActivity(MainActivity.this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);

                //set the content intent
                notification.setContentIntent(pendingIntent);

                //now to send the notification we use the NotificationManager
                NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                notificationManager.notify(uniqueID,notification.build());
            }
        });

    }
}
