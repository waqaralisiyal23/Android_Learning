package com.siyal.tipcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.TestLooperManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText enteredAmount;
    private SeekBar percentageSeekBar;
    private TextView textViewSeekbar;
    private Button calculate;
    private TextView txtTotalBill;
    private TextView result;

    private int percentage;
    private float billAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enteredAmount = (EditText) findViewById(R.id.billAmount);
        percentageSeekBar = (SeekBar) findViewById((R.id.seekBar));
        textViewSeekbar = (TextView) findViewById(R.id.textViewSeekBar);
        calculate = (Button) findViewById(R.id.btnCalculateTip);
        txtTotalBill = (TextView) findViewById(R.id.totalBill);
        result = (TextView) findViewById(R.id.resut);

        textViewSeekbar.setText(String.valueOf(percentageSeekBar.getProgress()));   //initially the progress is 0

        percentageSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textViewSeekbar.setText(String.valueOf(seekBar.getProgress()) + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                percentage = seekBar.getProgress();
            }
        });

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateTip();
            }
        });

    }

    public void calculateTip(){
        float tip = 0.0f;
        if( !(enteredAmount.getText().toString().isEmpty()) ) {
            billAmount = Float.parseFloat(enteredAmount.getText().toString());
            tip = billAmount * percentage/100;
            txtTotalBill.setText("Total Bill : $"+ enteredAmount.getText());
            result.setText("Your tip will be: $"+ String.valueOf(tip));
        }
        else
            Toast.makeText(MainActivity.this,"Please enter bill amount",Toast.LENGTH_LONG).show();
    }
}
