package com.siyal.threads;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private Button btnClickMe;

    Handler handler= new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            textView.setText("Button Clicked");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView);
        btnClickMe = (Button) findViewById(R.id.btnClickMe);


        btnClickMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Runnable r = new Runnable() {
                    @Override
                    public void run() {
                        long futureTime= System.currentTimeMillis() + 10000;    //10000 milliseconds = 10 seconds
                        while(System.currentTimeMillis()<futureTime){
                            synchronized (this){
                                try{
                                    wait(futureTime-System.currentTimeMillis());
                                }
                                catch(Exception e){

                                }
                            }
                        }
                        handler.sendEmptyMessage(0);
                    }
                };
                /* Due to code below our application will crash so we write this code in run method of Runnable interface
                long futureTime= System.currentTimeMillis() + 10000;    //10000 milliseconds = 10 seconds
                while(System.currentTimeMillis()<futureTime){
                    synchronized (this){
                        try{
                            wait(futureTime-System.currentTimeMillis());
                        }
                        catch(Exception e){

                        }
                    }
                }
                 */

                Thread myThread = new Thread(r);
                myThread.start();

            }
        });
    }
}
