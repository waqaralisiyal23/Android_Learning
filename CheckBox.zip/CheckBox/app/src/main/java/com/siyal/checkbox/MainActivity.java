package com.siyal.checkbox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.CheckBox;

public class MainActivity extends AppCompatActivity {

    private CheckBox momCheckBox;
    private CheckBox dadCheckBox;
    private CheckBox grandpaCheckBox;
    private Button showButton;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        momCheckBox = (CheckBox) findViewById(R.id.momCheckBox);
        dadCheckBox = (CheckBox) findViewById(R.id.dadCheckBox);
        grandpaCheckBox = (CheckBox) findViewById(R.id.grandpaCheckBox);
        showButton = (Button) findViewById(R.id.showButton);
        result = (TextView) findViewById(R.id.txtResult);

        showButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(momCheckBox.getText().toString()+" status is: "+momCheckBox.isChecked()+"\n");
                stringBuilder.append(dadCheckBox.getText().toString()+" status is: "+dadCheckBox.isChecked()+"\n");
                stringBuilder.append(grandpaCheckBox.getText().toString()+" status is: "+grandpaCheckBox.isChecked()+"\n");
                result.setText(stringBuilder);
            }
        });
    }
}
