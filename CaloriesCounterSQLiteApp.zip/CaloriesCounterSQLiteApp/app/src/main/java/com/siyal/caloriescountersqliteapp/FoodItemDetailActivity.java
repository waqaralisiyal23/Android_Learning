package com.siyal.caloriescountersqliteapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import data.DatabaseHandler;
import model.Food;

public class FoodItemDetailActivity extends AppCompatActivity {

    private TextView foodName;
    private TextView foodCalories;
    private TextView foodAddedDate;
    private Button btnShare;

    private int foodId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_item_detail);

        foodName = (TextView) findViewById(R.id.detailsFoodName);
        foodCalories = (TextView) findViewById(R.id.detailsCaloriesValue);
        foodAddedDate = (TextView) findViewById(R.id.detailsDate);
        btnShare = (Button) findViewById(R.id.detailsShareButton);

        Food food = (Food) getIntent().getSerializableExtra("userObject");

        foodName.setText(food.getFoodName());
        foodCalories.setText(String.valueOf(food.getCalories()));
        foodAddedDate.setText(food.getFoodAddedDate());

        foodId = food.getFoodId();

        foodCalories.setTextSize(34.9f);
        foodCalories.setTextColor(Color.RED);

        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareCalories();
            }
        });
    }

    private void shareCalories(){
        StringBuilder stringBuilder = new StringBuilder();

        String name = foodName.getText().toString();
        String cals = foodCalories.getText().toString();
        String date = foodAddedDate.getText().toString();

        stringBuilder.append("Food: "+name+"\nCalories: "+cals+"\nEaten on: "+date);

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("message/rfc822");
        intent.putExtra(Intent.EXTRA_SUBJECT,"My Caloric Intake");
        intent.putExtra(Intent.EXTRA_EMAIL,new String[]{"recipient@example.com"});
        intent.putExtra(Intent.EXTRA_TEXT, stringBuilder.toString());

        try{
            startActivity(Intent.createChooser(intent,"Send Mail..."));
        }catch (ActivityNotFoundException e){
            Toast.makeText(FoodItemDetailActivity.this,"Please install email client before sending...",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_food_item_details,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.deleteItem){
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(FoodItemDetailActivity.this);
            dialogBuilder.setTitle("Delete?");
            dialogBuilder.setMessage("Are you sure you want to delete this item?");

            dialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            dialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    DatabaseHandler myDB = new DatabaseHandler(FoodItemDetailActivity.this);
                    boolean isDeleted = myDB.deleteFood(foodId);
                    if(isDeleted) {
                        Toast.makeText(FoodItemDetailActivity.this, "Food Item Deleted", Toast.LENGTH_LONG).show();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                startActivity(new Intent(FoodItemDetailActivity.this,DisplayFoods.class));
                                //remove this activity from activity stack
                                FoodItemDetailActivity.this.finish();
                            }
                        }, 1500);    //delay for 1.5 second
                    }
                    else
                        Toast.makeText(FoodItemDetailActivity.this, "Deletion Failed!", Toast.LENGTH_LONG).show();

                }
            });

            AlertDialog alertDialog = dialogBuilder.create();
            alertDialog.show();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(FoodItemDetailActivity.this,DisplayFoods.class));
        FoodItemDetailActivity.this.finish();
    }
}
