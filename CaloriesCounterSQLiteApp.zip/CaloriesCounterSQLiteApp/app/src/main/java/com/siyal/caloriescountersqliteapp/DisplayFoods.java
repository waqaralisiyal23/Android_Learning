package com.siyal.caloriescountersqliteapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import data.CustomListViewAdapter;
import data.DatabaseHandler;
import model.Food;
import util.Utils;

public class DisplayFoods extends AppCompatActivity {

    private DatabaseHandler myDB;
    private ArrayList<Food> dbFoods = new ArrayList<>();
    private CustomListViewAdapter foodAdapter;
    private ListView listView;
    private Food myFood;

    private TextView totalFoods;
    private TextView totalCals;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_foods);

        myDB = new DatabaseHandler(DisplayFoods.this);

        listView = (ListView) findViewById(R.id.list);
        totalFoods = (TextView) findViewById(R.id.totalItemsTextView);
        totalCals = (TextView) findViewById(R.id.totalAmountTextView);

        refreshData();
    }

    private void refreshData() {
        dbFoods.clear();
        ArrayList<Food> foodsFromdb = myDB.getAllFoods();

        int calsValue = myDB.getTotalCalories();
        int totalItems = myDB.getTotalItems();

        String formattedValue = Utils.formatNumber(calsValue);
        String formattedItems = Utils.formatNumber(totalItems);

        totalCals.setText("Total Calories: "+formattedValue);
        totalFoods.setText("Total Foods: "+formattedItems);

        for(int i=0;i<foodsFromdb.size();i++){
            int id = foodsFromdb.get(i).getFoodId();
            String name = foodsFromdb.get(i).getFoodName();
            int cals = foodsFromdb.get(i).getCalories();
            String date = foodsFromdb.get(i).getFoodAddedDate();

            myFood = new Food(name,cals,id,date);

            dbFoods.add(myFood);
        }

        myDB.close();

        //setup adapter
        foodAdapter = new CustomListViewAdapter(DisplayFoods.this,R.layout.list_row,dbFoods);
        listView.setAdapter(foodAdapter);
        foodAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Inflates the menu: this adds the items to the action bar if it is parent
        //getMenuInflater().inflate(R);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return super.onOptionsItemSelected(item);
    }
}
