package com.siyal.caloriescountersqliteapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import data.DatabaseHandler;
import model.Food;

public class MainActivity extends AppCompatActivity {

    private EditText foodEditText;
    private EditText caloriesEditText;
    private Button submitbutton;
    private Button showButton;

    private DatabaseHandler myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        foodEditText = (EditText) findViewById(R.id.foodEditText);
        caloriesEditText = (EditText) findViewById(R.id.caloriesEditText);
        submitbutton = (Button) findViewById(R.id.submitButton);
        showButton = (Button) findViewById(R.id.showButton);

        myDB = new DatabaseHandler(MainActivity.this);

        submitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if( !(foodEditText.getText().toString().isEmpty()) && !(caloriesEditText.getText().toString().isEmpty()) )
                    saveToDb();
                else
                    Toast.makeText(MainActivity.this,"Please fill both the fields!",Toast.LENGTH_LONG).show();
            }
        });

        showButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,DisplayFoods.class));
            }
        });


    }

    public void saveToDb(){
        String name = foodEditText.getText().toString();
        int calories = Integer.parseInt(caloriesEditText.getText().toString());

        Food food = new Food(name,calories);

        boolean isInserted = myDB.addFood(food);
        if(isInserted) {
            Toast.makeText(MainActivity.this, "Food Added!", Toast.LENGTH_LONG).show();

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(new Intent(MainActivity.this,DisplayFoods.class));
                }
            },1500);   //delay for 1.5 seconds
        }
        else
            Toast.makeText(MainActivity.this,"Food Insertion Failed!",Toast.LENGTH_LONG).show();
    }
}
