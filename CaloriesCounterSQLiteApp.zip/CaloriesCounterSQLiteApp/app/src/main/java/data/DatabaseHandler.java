package data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;

import model.Food;
import util.Constants;

public class DatabaseHandler extends SQLiteOpenHelper {

    private final ArrayList<Food> foodList = new ArrayList<>();

    public DatabaseHandler(@Nullable Context context) {
        super(context, Constants.DB_NAME, null, Constants.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_FOOD_TABLE = "CREATE TABLE "+Constants.TABLE_NAME+"("+Constants.KEY_ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+
                                    Constants.FOOD_NAME+" TEXT,"+Constants.FOOD_CALORIES_NAME+" INTEGER,"+
                                    Constants.DATE_NAME+" LONG);";
        db.execSQL(CREATE_FOOD_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+Constants.TABLE_NAME);
        onCreate(db);
    }

    /**
     * CRUD Operations: CREATE,READ,UPDATE,DELETE
     */

    //Get Total items saved
    public int getTotalItems(){
        SQLiteDatabase db = this.getReadableDatabase();
        String countQuery = "SELECT * FROM "+Constants.TABLE_NAME;
        Cursor cursor = db.rawQuery(countQuery,null);
        return cursor.getCount();
    }

    //get total Calories
    public int getTotalCalories(){
        int cals=0;
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT sum("+Constants.FOOD_CALORIES_NAME+") FROM "+Constants.TABLE_NAME;
        Cursor cursor = db.rawQuery(query,null);
        if(cursor.moveToFirst())     //if there is any record
            cals = cursor.getInt(0);
        cursor.close();
        db.close();
        return cals;
    }

    //delete food item
    public boolean deleteFood(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        int i = db.delete(Constants.TABLE_NAME,Constants.KEY_ID+" = ? ",new String[]{String.valueOf(id)});
        if(i>0)
            return true;
        db.close();
        return false;
    }

    //add food item
    public boolean addFood(Food food){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Constants.FOOD_NAME,food.getFoodName());
        values.put(Constants.FOOD_CALORIES_NAME,food.getCalories());
        values.put(Constants.DATE_NAME,System.currentTimeMillis());

        long i = db.insert(Constants.TABLE_NAME,null,values);
        db.close();

        if(i!=-1)
            return true;
        return false;
    }

    //get all food items
    public ArrayList<Food> getAllFoods(){
        foodList.clear();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query( Constants.TABLE_NAME,new String[]{Constants.KEY_ID,Constants.FOOD_NAME,Constants.FOOD_CALORIES_NAME,Constants.DATE_NAME},
                                 null,null,null,null,Constants.DATE_NAME+" DESC");

        if(cursor.moveToFirst()){
            do{
                Food food = new Food();
                food.setFoodId(cursor.getInt(cursor.getColumnIndex(Constants.KEY_ID)));
                food.setFoodName(cursor.getString(cursor.getColumnIndex(Constants.FOOD_NAME)));
                food.setCalories(cursor.getInt(cursor.getColumnIndex(Constants.FOOD_CALORIES_NAME)));

                DateFormat dateFormat = DateFormat.getDateInstance();
                String date = dateFormat.format(new Date(cursor.getLong(cursor.getColumnIndex(Constants.DATE_NAME))).getTime());

                food.setFoodAddedDate(date);

                foodList.add(food);
            }while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return foodList;
    }

}
