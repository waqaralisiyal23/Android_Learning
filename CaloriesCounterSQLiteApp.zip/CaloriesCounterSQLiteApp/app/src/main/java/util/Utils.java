package util;

import java.text.DecimalFormat;

public class Utils {
    //1000 show this 1,000 and 1000000 to 1,000,000
    public static String formatNumber(int value){
        DecimalFormat formatter = new DecimalFormat("#,###,###");
        String formatted = formatter.format(value);
        return formatted;
    }
}
