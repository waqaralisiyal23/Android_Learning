package com.siyal.alertdialog;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private AlertDialog.Builder alertDialog;
    private Button showDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showDialog = (Button) findViewById(R.id.showDialog);
        showDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog = new AlertDialog.Builder(MainActivity.this);  //alertDialog belongs to the MainActivity
                //setting things up-set title
                //alertDialog.setTitle(R.string.title);   //There is another way to use string like this
                alertDialog.setTitle(getResources().getString(R.string.title));
                //sets the icon
                alertDialog.setIcon(android.R.drawable.btn_star_big_on);
                //set message
                alertDialog.setMessage(getResources().getString(R.string.message));
                //set cancelable
                alertDialog.setCancelable(false);   //means user yes ya no select krega cancel ni kr skta dialog ko
                //set positive button
                alertDialog.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MainActivity.this.finish();    //Application exit hujyegi
                    }
                });
                //set negative button
                alertDialog.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();    //dialogbox khtm hujyega
                    }
                });

                //creating the actual dialog
                AlertDialog dialog = alertDialog.create();
                dialog.show();

            }
        });
    }
}
