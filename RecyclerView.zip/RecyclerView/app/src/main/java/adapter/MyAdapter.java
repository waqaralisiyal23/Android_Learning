package adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.siyal.recyclerview.DetailsActivity;
import com.siyal.recyclerview.R;

import java.util.List;

import model.ListItem;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    private Context context;
    private List<ListItem> listItem;                   //ListItem is a model class created by own in model package
    public MyAdapter(Context context, List listItem){
        this.context=context;
        this.listItem=listItem;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //idhr hum btate hain ke card kahan se a rha hai
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.ViewHolder holder, int position) {
        //holder jo hai wo ViewHolder ka object hai jo MyAdapter ki subclass hai
        //idhr card k andr jo data hai usko set krte hain
        ListItem item = listItem.get(position);    //ye position wo hai jo btayegi ham kis row pe hain
        holder.name.setText(item.getName());
        holder.description.setText(item.getDescription());
        holder.rating.setText(item.getRating());
    }

    @Override
    public int getItemCount() {
        return listItem.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        //hold all of the items

        public TextView name;
        public TextView description;
        public TextView rating;

        public ViewHolder(View itemView) {
            super(itemView);

            name = (TextView) itemView.findViewById(R.id.title);
            description = (TextView) itemView.findViewById(R.id.description);
            rating = (TextView) itemView.findViewById(R.id.rating);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            //Get position of the row clicked or tapped
            int position = getAdapterPosition();

            ListItem item = listItem.get(position);

            //Here context is MainActivitiy
            Intent intent = new Intent(context, DetailsActivity.class);
            intent.putExtra("name",item.getName());
            intent.putExtra("description",item.getDescription());
            intent.putExtra("rating",item.getRating());
            context.startActivity(intent);    //We are inside our Adapter class not in MainActivity therefore we have to go through the cotext which is
                                                //our MainActivity
        }
    }
}
