package com.siyal.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

import adapter.MyAdapter;
import model.ListItem;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private List<ListItem> listItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);

        recyclerView.setHasFixedSize(true);   //Sab ki size fix hugi
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        listItem = new ArrayList<>();

        ListItem item1 = new ListItem("Movie1","This one was Horror..","Awesome movie!");
        ListItem item2 = new ListItem("Movie2","This one was funny..","Great one!");
        ListItem item3 = new ListItem("Movie3","Action movie..","Nice!");
        ListItem item4 = new ListItem("Movie4","This one depends on love story..","Good movie!");
        ListItem item5 = new ListItem("Movie5","This one was about a teacher..","Better one!");
        ListItem item6 = new ListItem("Movie6","This was funny and horror..","Excellent!");
        ListItem item7 = new ListItem("Movie7","This one was based on life lessons..","Fine!");
        ListItem item8 = new ListItem("Movie8","This movie has interesting story..","Great!");
        ListItem item9 = new ListItem("Movie9","It's about someone crazy..","Awesome movie!");
        ListItem item10 = new ListItem("Movie10","It's about someone you..","Loved it!");

        /*
        for(int i=1;i<=10;i++){
            ListItem item = new ListItem("Item "+i,"Description","Excellent");
            listItem.add(item);
        }
         */

        listItem.add(item1);
        listItem.add(item2);
        listItem.add(item3);
        listItem.add(item4);
        listItem.add(item5);
        listItem.add(item6);
        listItem.add(item7);
        listItem.add(item8);
        listItem.add(item9);
        listItem.add(item10);

        adapter = new MyAdapter(this,listItem);
        recyclerView.setAdapter(adapter);
    }
}
