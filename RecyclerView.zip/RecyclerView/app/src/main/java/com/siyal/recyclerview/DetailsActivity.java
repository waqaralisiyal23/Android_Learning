package com.siyal.recyclerview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DetailsActivity extends AppCompatActivity {

    private TextView txtName;
    private TextView txtDescription;
    private TextView txtRating;

    private Bundle extras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        txtName = (TextView) findViewById(R.id.txtName);
        txtDescription = (TextView) findViewById(R.id.txtDescription);
        txtRating = (TextView) findViewById(R.id.txtRating);

        extras = getIntent().getExtras();
        if(extras!=null){
            txtName.setText(extras.getString("name"));
            txtDescription.setText(extras.getString("description"));
            txtRating.setText(extras.getString("rating"));
        }
    }
}
