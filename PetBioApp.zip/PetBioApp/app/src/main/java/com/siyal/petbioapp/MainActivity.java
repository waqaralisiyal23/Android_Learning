package com.siyal.petbioapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private ImageView cat;
    private ImageView dog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cat = (ImageView) findViewById(R.id.catView);
        dog = (ImageView) findViewById(R.id.dogView);

        //As ImageView and Button are all derived from view so we can apply click listener

        cat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent catIntent = new Intent(MainActivity.this,BioActivity.class);
                catIntent.putExtra("name","Jarvis");
                catIntent.putExtra("bio","Great Cat. Loves people and meows a lot");
                startActivity(catIntent);

            }
        });

        dog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent dogIntent = new Intent(MainActivity.this,BioActivity.class);
                dogIntent.putExtra("name","Dufus");
                dogIntent.putExtra("bio","Great Dog. Loves people and barks and eats a lot");
                startActivity(dogIntent);
            }
        });

    }
}
