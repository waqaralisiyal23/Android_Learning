package com.siyal.petbioapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class BioActivity extends AppCompatActivity {

    private ImageView view;
    private TextView txtName;
    private TextView txtPetBio;

    private Bundle extras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bio);

        view = (ImageView) findViewById(R.id.imageView);
        txtName = (TextView) findViewById(R.id.txtName);
        txtPetBio = (TextView) findViewById(R.id.txtPetBio);

        extras = getIntent().getExtras();
        if(extras!=null){
            String name = extras.getString("name");
            String bio = extras.getString("bio");
            setUp(name,bio);
        }

    }

    public void setUp(String name,String bio){
        if(name.equals("Jarvis")){
            //Cat stuff
            view.setImageDrawable(getResources().getDrawable(R.drawable.cat));
            txtName.setText(name);
            txtPetBio.setText(bio);
        }
        else if(name.equals("Dufus")){
            //dog stuff
            view.setImageDrawable(getResources().getDrawable(R.drawable.dog));
            txtName.setText(name);
            txtPetBio.setText(bio);
        }
    }
}
