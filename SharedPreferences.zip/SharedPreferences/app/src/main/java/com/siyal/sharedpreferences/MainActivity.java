package com.siyal.sharedpreferences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText myEditText;
    private Button saveButton;
    private TextView resultTextView;
    private SharedPreferences myPrefs;
    private static final String PREFS_NAME= "myPrefsFile";  //becuase shared peferences file that is created, internally what happes actually is android creates
    //an xml file and stores all the information for us and we are giving the name to that xml file so that we can access it

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myEditText = (EditText) findViewById(R.id.editText);
        saveButton = (Button) findViewById(R.id.button);
        resultTextView = (TextView) findViewById(R.id.textView);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myPrefs = getSharedPreferences(PREFS_NAME,0);
                SharedPreferences.Editor editor = myPrefs.edit();   //This editor will allow us to start adding items into SharedPreferneces
                //We will store information in key,value pairs
                editor.putString("message",myEditText.getText().toString());
                editor.commit();   //to save data
            }
        });

        //Get data back from shared Preferences
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME,0);
        if(prefs.contains("message")){
            String message = prefs.getString("message","Not Found");
            resultTextView.setText(message);
        }
    }
}
