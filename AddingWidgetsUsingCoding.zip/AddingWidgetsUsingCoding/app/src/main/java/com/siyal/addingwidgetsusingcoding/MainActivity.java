package com.siyal.addingwidgetsusingcoding;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.widget.RelativeLayout;
import android.widget.Button;
import android.graphics.Color;
import android.widget.EditText;
import android.content.res.Resources;
import android.util.TypedValue;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        RelativeLayout myLayout = new RelativeLayout(this);
        myLayout.setBackgroundColor(Color.BLUE);

        Button myButton = new Button(this);
        myButton.setText("Click Here");
        myButton.setBackgroundColor(Color.RED);
        myButton.setId(1);

        EditText username = new EditText(this);
        //To set width of the EditText we use DIP-density independent pixels
        //We will convert DIP to pixels so that interface remains same in every device
        Resources r = getResources();
        int pixels = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,200,r.getDisplayMetrics());

        username.setWidth(pixels);
        username.setHint("Enter Username: ");
        username.setId(2);

        RelativeLayout.LayoutParams buttonDetails = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,
                                                                                    RelativeLayout.LayoutParams.WRAP_CONTENT);

        buttonDetails.addRule(RelativeLayout.CENTER_HORIZONTAL);
        buttonDetails.addRule(RelativeLayout.CENTER_VERTICAL);

        RelativeLayout.LayoutParams usernameDetails = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,
                                                                                      RelativeLayout.LayoutParams.WRAP_CONTENT);
        usernameDetails.addRule(RelativeLayout.ABOVE,myButton.getId());
        usernameDetails.addRule(RelativeLayout.CENTER_HORIZONTAL);
        usernameDetails.setMargins(0,0,0,50);

        myLayout.addView(myButton,buttonDetails);
        myLayout.addView(username,usernameDetails);

        setContentView(myLayout);
    }
}
