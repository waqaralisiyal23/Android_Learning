package com.siyal.contextandtoastclass;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Context is abstract class, see its documentation from developer.android.com and all its implementation
    //Through Context we can get access packages,packagenames,drawable and many things.


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toast.makeText(this,"Hello",Toast.LENGTH_LONG).show();
        //Toast.makeText(getBaseContext(),"Hello",Toast.LENGTH_LONG).show();    //can also used
        //Toast.makeText(getApplication(),"Hello",Toast.LENGTH_LONG).show();    //can also used

        //Through Context we can get access packages,packagenames,drawable and many things.
        Log.d("App Name:",getApplicationContext().getString(R.string.app_name));
    }
}
