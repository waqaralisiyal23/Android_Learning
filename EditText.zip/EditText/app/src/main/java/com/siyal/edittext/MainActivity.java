package com.siyal.edittext;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private TextView textView;
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.button);     //To get reference of the button
        textView = (TextView) findViewById(R.id.textView);
        editText = (EditText) findViewById(R.id.editText);

        button.setText(R.string.button_name);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String enteredText = editText.getText().toString();

                textView.setVisibility(View.VISIBLE);
                textView.setText(enteredText);
            }
        });

    }
}
