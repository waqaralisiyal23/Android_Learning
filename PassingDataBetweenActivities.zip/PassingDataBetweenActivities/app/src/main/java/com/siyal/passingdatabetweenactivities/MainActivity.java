package com.siyal.passingdatabetweenactivities;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button gotoSecondActivity;

    private final int REQUEST_CODE=2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gotoSecondActivity = (Button) findViewById(R.id.showNextActivity);
        gotoSecondActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,SecondActivity.class);
                //intent.putExtra(name,value)
                intent.putExtra("message1","Hello from first activity");
                intent.putExtra("message2","Hello again");
                intent.putExtra("value",123);
                //startActivity(intent);   //data back bhi lena hai tou ye use ni krengy
                startActivityForResult(intent,REQUEST_CODE);   //For getting the data back or results

            }
        });
    }

    //To get data back to fisrt activity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==REQUEST_CODE){
            if(resultCode==RESULT_OK){
                String result = data.getStringExtra("returnData");
                Toast.makeText(MainActivity.this,result,Toast.LENGTH_LONG).show();
            }
        }
    }
}
