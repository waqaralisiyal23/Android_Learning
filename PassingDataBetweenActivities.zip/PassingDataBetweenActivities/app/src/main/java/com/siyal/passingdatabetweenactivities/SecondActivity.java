package com.siyal.passingdatabetweenactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    private TextView message1;
    private TextView message2;
    private TextView value;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Bundle extras = getIntent().getExtras();

        message1 = (TextView) findViewById(R.id.message1);
        message2 = (TextView) findViewById(R.id.message2);
        value = (TextView) findViewById(R.id.value);
        backButton = (Button) findViewById(R.id.backButton);

        if(extras!=null){
            String msg1 = extras.getString("message1");
            String msg2 = extras.getString("message2");
            int val = extras.getInt("value");

            message1.setText(msg1);
            message2.setText(msg2);
            value.setText(String.valueOf(val));
        }

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = getIntent();
                returnIntent.putExtra("returnData","From SecondActivity");
                setResult(RESULT_OK,returnIntent);
                finish();
            }
        });

    }
}
